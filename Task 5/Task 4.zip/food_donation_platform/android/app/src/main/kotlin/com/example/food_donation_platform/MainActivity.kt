package com.example.food_donation_platform

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
